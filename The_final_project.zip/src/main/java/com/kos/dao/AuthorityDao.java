package com.kos.dao;

import com.kos.vo.AuthorityVO;

public interface AuthorityDao {
	public abstract int roleInsert(String id,String role);
}
