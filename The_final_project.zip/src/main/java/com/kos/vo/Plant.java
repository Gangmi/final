package com.kos.vo;

public interface Plant {
	public static final int FREE_BOARD=1;
}
