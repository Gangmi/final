package com.kos.vo;

public class SmartFarmDeviceVO {
	private String devicekey;
	private String id;
	private String regdate;
	private String rentdate;
	private String waterdate;
	public String getDevicekey() {
		return devicekey;
	}
	public void setDevicekey(String devicekey) {
		this.devicekey = devicekey;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getRentdate() {
		return rentdate;
	}
	public void setRentdate(String rentdate) {
		this.rentdate = rentdate;
	}
	public String getWaterdate() {
		return waterdate;
	}
	public void setWaterdate(String waterdate) {
		this.waterdate = waterdate;
	}
	
}
