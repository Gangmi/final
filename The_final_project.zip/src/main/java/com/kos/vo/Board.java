package com.kos.vo;

public interface Board {
	public static final int FREE_BOARD=1;
	
}
