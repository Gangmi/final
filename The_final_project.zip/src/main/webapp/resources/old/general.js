$(document).ready(function() { 
	
/*
	$("#write_board").click(function(evt) {
		window.location.href="writeboard.do?m_id=test"
	});
*/
});